
<div style="clear:both"> &nbsp; </div>
<!-- BEGIN FOOTER -->
<div class="footer"><p class="copyright-v2"> 2018 &copy; Merchware. All Rights Reserved.</p></div>
	<a href="#index" class="go2top">
        <i class="icon-arrow-up"></i>
    </a>
<!-- END FOOTER -->

